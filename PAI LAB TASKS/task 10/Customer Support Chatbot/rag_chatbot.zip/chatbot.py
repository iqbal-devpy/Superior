import chromadb
from sentence_transformers import SentenceTransformer

client = chromadb.PersistentClient(path="./chroma_db")
collection = client.get_or_create_collection("ecommerce_chatbot")
embedder = SentenceTransformer("all-MiniLM-L6-v2")

def retrieve_answer(query):
    query_embedding = embedder.encode([query]).tolist()[0]
    results = collection.query(query_embeddings=[query_embedding], n_results=3)
    return " ".join(results["documents"][0]) if results["documents"] else "No relevant info found."
