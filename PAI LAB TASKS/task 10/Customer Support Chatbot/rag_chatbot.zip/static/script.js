function sendMessage() {
    let inputField = document.getElementById("user-input");
    let userMessage = inputField.value;
    inputField.value = "";

    let chatBox = document.getElementById("chat-box");
    chatBox.innerHTML += "<p><strong>You:</strong> " + userMessage + "</p>";

    fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: userMessage })
    })
    .then(response => response.json())
    .then(data => {
        chatBox.innerHTML += "<p><strong>Bot:</strong> " + data.response + "</p>";
    });
}
